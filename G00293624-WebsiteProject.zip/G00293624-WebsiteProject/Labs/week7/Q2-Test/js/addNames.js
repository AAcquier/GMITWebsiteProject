//create functions for add(), clear_storage() and names object

function clear_storage(){
	localStorage.clear();
}
//add function to use localStorage object.

function names(fname,lname){
	this.fname=fname;
	this.lname=lname;
}

function add(){
	var obj_key="obj_key_"+localStorage.length;
	
	localStorage.setItem(obj_key, JSON.stringify(new names(document.getElementById("fld1").value, document.getElementById("fld2").value)));
	alert(localStorage.length);
	window.location.reload();
	
}