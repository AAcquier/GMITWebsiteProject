//add a load event listener to the body of nameList.html
var el= document.getElementById("namesListBody");
el.addEventListener('load',populate_page, true);

//event listener to invoke this function:
function populate_page() {
	//Add code here to complete exercise to create the table and add it to div element on the page
	var divContent="<table border='1px solid black' id='t1'><tr><td> First Name</td><td>Surname</td></tr>";
	var i;
	for(i=0; i<localStorage.length; i++){
		var parsedObject= JSON.parse(localStorage.getItem("obj_key_"+i));
		if (i==0){
			divContent+="<tr><td><b>"+parsedObject.fname+"</b></td><td><b>"+parsedObject.lname+"</b></td></tr>";
		}else{
			divContent+="<tr><td>"+parsedObject.fname+"</td><td>"+parsedObject.lname+"</td></tr>";
		}
	}
	
	divContent+="</table>";
	var divEl=document.getElementById("nameList");
	divEl.innerHTML=divContent;
	
	//added the following to create a reference to js/clickEvent.js within <head> tag.
	var clickEventRef=document.createElement('script');
	clickEventRef.setAttribute("type","text/javascript");
	clickEventRef.setAttribute("src","js/clickEvent.js");
	document.getElementsByTagName("head")[0].appendChild(clickEventRef);
}



/* In class test code
var el=document.getElementById('namesListBody');
el.addEventListener('blur', populate_page, false);

function showElement() {
  alert(this.innerHTML);
}

el = document.getElementById("nameList");
el.addEventListener('click', showElement, false);

el = document.getElementById("namesListBody");   
el.addEventListener('click', showElement, false);


function populate_page{
	document.write("<table border='1px solid black' id='t1'><tr><td>First Name</td><td>Surname</td></tr>")

	function fromStorage(){
	var i;
	for(i=0; i<localStorage.length;i++){
		var parsedObject=JSON.parse(localStorage.getItem("obj_key_"+i))
		alert(parsedObject.names);
		document.write("<td><b>obj_key_1</b></td><td><b>obj_key_2</b></td>")
	}
}
	}*/
