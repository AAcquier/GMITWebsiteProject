<!DOCTYPE html>
<html>
<head>
	<title>Sessions</title>	
</head>
<body>
	<?php
	
		/* Add username to a cookie. This code will be invoked when the "Add to cookie" button is clicked.
		   The cookie should be set to expire after 1 hour. 	
		   HINT: refer to slide 38 of PHP Lecture on moodle */
		if(isset($_POST["add"])){
			if(isset($_POST['username'])){
				/* start the session. Must always be included for each page 
				requiring so it can access the session */
				session_start();
				$_SESSION['username'] = $_POST['username'];// Add data to the session
			}
		}
		/* Add code which is invoked when the "Clear Cookie" button is clicked
		   The code should ensure the Cookie is destroyed 
		   HINT: refer to slide 39 of PHP Lecture on moodle */
		   if (isset($_POST["clear"])){
			   session_start();// start the session
			   $_SESSION=array();//reset the session array to clear the data from any variables
			   session_destroy();// then delete the session data from the server
		   }
	?>
	
	<form action="storage.php" method="post">
		<input type="text" name="username">
		<input type="submit" name="add" value="Add to session">
		<input type="submit" name="clear" value="Clear Session">
	</form>
	<br>
	<form action="welcome.php">
		<input type="submit" name="welcome" value="Go to welcome page">
	</form>
	
</body>
</html>
	
