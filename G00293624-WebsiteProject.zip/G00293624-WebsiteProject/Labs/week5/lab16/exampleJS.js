var name="Alex";

document.write("<h1>Create page from Javascript</h1>");
document.write("<p>Hello World</p>");
document.write("<button onclick='clicked()'>Add</button>");


function clicked(){
	alert("The name is "+name);
}