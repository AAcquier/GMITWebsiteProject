
var el=document.getElementById("shoppingList");
el.addEventListener("click", function(e){
	itemDone(e);
}, false);

function itemDone(e){
	var target=e.target;
	var ellistitem=target.parentNode;
	var elList=ellistitem.parentNode;
	elList.removeChild(ellistitem);
}