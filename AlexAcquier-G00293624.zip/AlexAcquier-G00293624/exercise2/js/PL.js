$(document).ready(function(){
	var $newContent='<tr><th>Pos</th><th>Team</th><th>P</th><th>Pts</th><th>F</th><th>A</th><th>GD</th><th>W</th><th>D</th><th>L</th></tr>';
	
	$.ajax({
		type:'GET',
		url:'data/league_table.json',
		dataType:'json',
		success:function(json){
			
			$(json).find('event').each(function(){
			
				$newContent+='<tr id="event"><td>'+$(this).find('Pos').text()+'</td>';
				$newContent+='<td>'+$(this).find('Team').text()+'</td>';
				$newContent+='<td>'+$(this).find('P').text()+'</td>';
				$newContent+='<td>'+$(this).find('Pts').text()+'</td>';
				$newContent+='<td>'+$(this).find('F').text()+'</td>';
				$newContent+='<td>'+$(this).find('A').text()+'</td>';
				$newContent+='<td>'+$(this).find('GD').text()+'</td>';
				$newContent+='<td>'+$(this).find('W').text()+'</td>';
				$newContent+='<td>'+$(this).find('D').text()+'</td>';
				$newContent+='<td>'+$(this).find('L').text()+'</td>';
				console.log($newContent);
			})
			
			$('#content').html($newContent);
		},
		error:function(){
			alert('The JSON file could not be accessed.')
		}
	});
});


/*var xhr=new XMLHttpRequest();

xhr.onload=function(){
	responseObject=JSON.parse(xhr.responseText);
	
	var newContent='<tr><th>Pos</th><th>Team</th><th>P</th><th>Pts</th><th>F</th><th>A</th><th>GD</th><th>W</th><th>D</th><th>L</th></tr>';
	
	for (var i=0;i<=5;i++){
		//newContent+='<div class="event">';
		//newContent+='<table>';
		//newContent+='<tr><th>Pos</th><th>Team</th><th>P</th><th>Pts</th><th>F</th><th>A</th><th>GD</th><th>W</th><th>D</th><th>L</th></tr>';
		newContent+='<tr><td>'+responseObject.standing[i].Pos+'</td>';
		newContent+='<td>'+responseObject.standing[i].Team+'</td>';
		newContent+='<td>'+responseObject.standing[i].P+'</td>';
		newContent+='<td>'+responseObject.standing[i].Pts+'</td>';
		newContent+='<td>'+responseObject.standing[i].F+'</td>';
		newContent+='<td>'+responseObject.standing[i].A+'</td>';
		newContent+='<td>'+responseObject.standing[i].GD+'</td>';
		newContent+='<td>'+responseObject.standing[i].W+'</td>';
		newContent+='<td>'+responseObject.standing[i].D+'</td>';
		newContent+='<td>'+responseObject.standing[i].L+'</td></tr>';
		//newContent+='</table><div>';
	}
	document.getElementById('content').innerHTML=newContent;
}

xhr.open('GET','data/league_table.json',true);
xhr.send(null);*/